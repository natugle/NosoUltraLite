
## Installing the visual package in Lazarus

1. Start Lazarus, go to components/open packaga file (`*.lpk`)
2. Open lnetvisual.lpk and install
3. Let Lazarus restart.

You can learn the basics by using the included examples or from [the lNet homepage](http://wiki.lazarus.freepascal.org/index.php/LNet)
